// 1. Define 2 functions
// 1st function named as checkEven which will check if the num passed is even or not.
// 2nd function named as filterEvens which will take an array of numbers and the checkEven function as arguments.
// This filterEvens function will filter out  only even numbers using the checkEven function and generate a new array of the even numbers.

//COMPLETE YOUR CODE HERE 
// Function to check if a number is even
const checkEven = (num) => num % 2 === 0;

// Function to filter only even numbers from an array
const filterEvens = (numbersArray) => numbersArray.filter(checkEven);

// Usage for the code to give the output
const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const evenNumbers = filterEvens(numbers);
console.log(evenNumbers); 
// Output: [2, 4, 6, 8, 10]



//2. Write an IIFE that calculates the factorial of a given number and immediately logs the result to the console.

//COMPLETE YOUR CODE HERE 
// IIFE to calculate the factorial
(function() {
    // Define the number we want the factorial of
    const number = 9;
    
    // Initialize a variable to hold the result of the factorial calculation
    let factorial = 4;
    
    // Calculate factorial by multiplying each number from 1 up to the given number
    for (let i = 4; i <= number; i++) {
        factorial *= i;
    }
    
    // Log the result to the console
    console.log("The factorial of " + number + " is: " + factorial);
})();
// Output is The factorial of 9 is: 241920



//3. The product1 object (which is already given) consists of title, price and category information of Nike Shoes.
// The description() function describes the product using its properties.
// Your task is to create a product2 object which consists of the title, price and category information of Sony TV.
// Next, use the call() method to invoke the description() method of product1 on product2.
// This should display the details of product2 on the console. 
var product1 = {
    title: "Nike Shoes",
    price: 30,
    category: "Shoes",
    description: function (){
        return "Title: " + this.title + " Price: " + this.price + " Category: " + this.category;
    }
}
//COMPLETE YOUR CODE HERE 
// Creating product2 with the details for Sony TV
var product2 = {
    title: "Sony TV",
    price: 300,
    category: "Electronics"
};

// We will use the call method to invoke description() of p1 and p2
console.log(product1.description.call(product2));
// Output: Title: Sony TV Price: 300 Category: Electronics


//4. Given an array of person objects, define a function to find oldest person object.

persons = [{"name" : "Harry", "age" : 12}, {"name" : "Ron", "age" : 11}, {"name" : "Hermione", "age" : 13}]
//COMPLETE YOUR CODE HERE 

// Creating the function to find the older person obj
function findOldestPerson(persons) {
    return persons.reduce((oldest, person) => {
        return person.age > oldest.age ? person : oldest;
    });
}

const oldestPerson = findOldestPerson(persons);
console.log(oldestPerson);
// Output: { name: 'Hermione', age: 13 }


//5.  Create a function that calculates the sum of an array using IIFE function and returns it.

//COMPLETE YOUR CODE HERE 
// IIFE to calculate the sum of an array
const sum = (function(arr) {
    return arr.reduce((accumulator, current) => accumulator + current, 0);
})([1, 3, 5, 7, 9]); // Here we will replace the array with any array I want to use to sum

console.log(sum);
// Output: 25


//6. Write a function printContext that, when invoked, logs the this keyword to the console. Then, demonstrate how the context of a function can change when calling it with different objects using the call method.

//COMPLETE YOUR CODE HERE 
// Defining the printContext function
function printContext() {
    console.log(this);
}

// Creating our objects
const per1 = {
    name: "Kyle",
    age: 30
};

const per2 = {
    name: "Dylan",
    age: 40
};

// Invoking the printContext
printContext();

// Change the context using the call method
printContext.call(per1);
printContext.call(per2);
// Output: { name: 'Kyle', age: 30 }
// { name: 'Dylan', age: 40 }


//7. Create a function multiply that takes two parameters and returns their product. Use the bind method to create a new function "double" that multiplies a single parameter by 2.

//COMPLETE YOUR CODE HERE 
// Defining the multiply function
function multiplyBy(x, y) {
    return x * y;
}

// Using the bind method to create our double function
const double = multiplyBy.bind(null, 2);

// Using the double function
console.log(double(8));
console.log(double(15));
// Output: 16 30

// 8. Create an object person with properties name and age. Write a function "introduce" that logs a message introducing the person. Then, use the call method to invoke the introduce function with the person object as the context.

//COMPLETE YOUR CODE HERE 
// Creating the object person
const person = {
    name: "Tyler",
    age: 25
};

// Writing the function "introduce"
function introduce() {
    console.log("Hi, my name is " + this.name + " and I am " + this.age + " years old.");
}

// Using the call method to invoke introduce with the person object as context
introduce.call(person);
// Output: Hi, my name is Tyler and I am 25 years old.


// 9. Write a higher order function createMultiplier that takes a factor as an argument and returns another functiom that multiplies a number by that factor. 

//COMPLETE YOUR CODE HERE 
// Defining the higher order function
function createMultiplier(factor) {
    // Return a new function that multiplies a number by the factor
    return function(number) {
        return number * factor;
    };
}

// Creating twice and third for our console log
const twice = createMultiplier(2);
const third = createMultiplier(3);

// Testing the functions
console.log(twice(5));  // Output: 10 (5 * 2)
console.log(twice(10)); // Output: 20 (10 * 2)
console.log(third(5));  // Output: 15 (5 * 3)
console.log(third(10)); // Output: 30 (10 * 3)

// 10. Write a function called "calculate" that adds two numbers and assign a property "description" to it with a string describing what the function does. Then, access and log this property.

//COMPLETE YOUR CODE HERE 
// Writing out the function for "calculate"
function calculate(a, b) {
    return a + b; // Adding two numbers
}

// Assigning a property "description" to the function
calculate.description = "This function will add two numbers!";

// Access and log the property
console.log(calculate.description);

// Calculating the function to show it works
const result = calculate(4, 8);
console.log(result);
// Output: This function will add two numbers!
// Output: 12
