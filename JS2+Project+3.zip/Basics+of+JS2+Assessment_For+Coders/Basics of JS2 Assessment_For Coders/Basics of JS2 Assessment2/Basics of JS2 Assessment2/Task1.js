// 1. Define and invoke an anonymous function square() which takes a number and returns its square.
// If input is 2, output should be 4.

//COMPLETE YOUR CODE HERE 
var square = function(num) {
    return num * num
};

console.log(square(2)); 
// Output: 4


// 2. Define an IIFE function which takes a personName as input and displays a greeting message containing the personName.
// If input is "Harry", output should be "Hello Harry, Welcome to Great Learning!"
(function (personName)
{
    console.log("Hello " + personName + ", Welcome to Great Learning!");
})("Harry"); // Output: Hello Harry, Welcome to Great Learning!



// 3. Define a global array variable containing 3 numbers. 
// Define a function which increments the value of each of the elements of this array by 2. 
// Display the array after you have invoked this function.

//COMPLETE YOUR CODE HERE 

// Define the global array with 3 numbers
var numbers = [1, 2, 3];

//Define a function to add 2 to each number in the array
function addTwoToEach() {
    // Go through each number in the array
    for (var i = 0; i < numbers.length; i++) {
        // We add 2 to the current number
        numbers[i] = numbers[i] + 2;
    }
}

// Call the function to update the array
addTwoToEach();

// We now display the updated urray
console.log(numbers); // Output: [3, 4, 5]



// 4. Create a "course" object having following information - 
// courseName as "Computer Science", durationInMonths as 24, level as "Beginner". 
// Display object information.
// Change the value of level as "Intermediate". 
// Display object information again.

//COMPLETE YOUR CODE HERE 
// We define the course object
var course = {
    courseName: "Computer Science",
    durationInMonths: 24,
    level: "Beginner"
};

// We display the initial object information using console log
console.log("Initial Course Information:");
console.log("Course Name: " + course.courseName);
console.log("Duration in Months: " + course.durationInMonths);
console.log("Level: " + course.level);

// Intermediate
course.level = "Intermediate";

// Update the object information
console.log("Update Course Information:");
console.log("Course Name: " + course.courseName);
console.log("Duration in Months: " + course.durationInMonths);
console.log("Level: " + course.level);
// Output: Initial Course Information:
// Course Name: Computer Science
// Duration in Months: 24
// Level: Beginner
// Update Course Information:
// Course Name: Computer Science
// Duration in Months: 24
// Level: Intermediate



// 5. Given an array "students" which is a collection of javascript objects where each object consists of information regarding one student. Write a code to iterate through each of these objects and extract first name and last name of each student.

var students = [
    { firstName: "Harry", lastName: "Potter", house: "Slytherin" },
    { firstName: "Ron", lastName: "Weasley", house: "Gryffindor" },
    { firstName: "Hermione", lastName: "Granger", house: "Gryffindor" }
];

//COMPLETE YOUR CODE HERE 
// Loop through each student
for (var i = 0; i < students.length; i++) {
    // We will access the current student
    var student = students[i];

    // We now extract the first name and last name
    var firstName = student.firstName;
    var lastName = student.lastName;

    // Display the console.log for the first and last name
    console.log("First Name: " + firstName + ", Last Name: " + lastName);
}
// Output: First Name: Harry, Last Name: Potter
// First Name: Ron, Last Name: Weasley
// First Name: Hermione, Last Name: Granger



// 6. Given a function doubleNumber which takes a number as an argument and returns its double value.
// Write a function which takes 2 arguments- 1st an array of numbers and 2nd the doubleNumber function as a callback function
// This function should iterate through each of the array number and use the doubleNumber function to double it.
// In the end it should display the updated array.
// We are not supposed to create a new array. We just need to update the existing array.

function doubleNumber(num) {
    return num * 2;
}

//COMPLETE YOUR CODE HERE 
// Function to double each number in the array using a callback
function doubleArrayElements(numbersArray, callback) {
    for (var i = 0; i < numbersArray.length; i++) {
        // Use the callback function to double each element in place
        numbersArray[i] = callback(numbersArray[i]);
    }

    // Display the updated array
    console.log(numbersArray);
}

// Example usage
var numbers = [1, 2, 3, 4, 5];
doubleArrayElements(numbers, doubleNumber); // Output: [2, 4, 6, 8, 10]



// 7. Implement a function called `multiplyBy` that multiplies a number by a specific factor using an IIFE (Immediately Invoked Function Expression).
// Hence, the IIFE function should return a function which should do the multiplication operation.

//COMPLETE YOUR CODE HERE 

// multiplyBy using an IIFE
var multiplyBy = (function() {
    // This function takes a factor and returns a new function
    return function(factor) {
        return function(number) {
            return number * factor; // Multiplies number by the factor
        };
    };
})();

var multiplyBy2 = multiplyBy(2); // Creates a function to multiply any number by 2
console.log(multiplyBy2(4));      // Output: 8

var multiplyBy5 = multiplyBy(5); // Creates a function to multiply any number by 5
console.log(multiplyBy5(3));      // Output: 15



//8. Using the `apply` method, write a function that finds the maximum number in an array. You can use Math class's built-in max() method for this task.

//COMPLETE YOUR CODE HERE 
// Function to find the maximum number in an array
function findMaxNumber(numbersArray) {
    // Use Math.max with the spread operator to find the maximum number
    var maxNumber = Math.max(...numbersArray);
    return maxNumber; // Return the maximum number found
}

var numbers = [5, 3, 8, 1, 4]; // Give a var for our numbers
var maxNum = findMaxNumber(numbers); // Call the function with the numbers array
console.log("The maximum number is: " + maxNum); 
// Output: The maximum number is: 8


//9. Declare an object named "car" with an empty object as its initial value. 
// Add the properties "make" and "model" with values "Toyota" and "Camry" respectively.

//COMPLETE YOUR CODE HERE 
// Declare an object named "car" with an empty object as its initial value
var car = {};

// Add properties "make" and "model" with values "Toyota" and "Camry" respectively
car.make = "Toyota"; // Setting the 'make' property
car.model = "Camry"; // Setting the 'model' property

// Display the car object to verify the properties
console.log(car); // Output: { make: 'Toyota', model: 'Camry' }


//10. Given an array "students" which is a collection of JavaScript objects where each object consists of information regarding one student.  
// Define a function displayByKey() which takes this array of objects and a keyName(as string) as arguments and displays the value of the key for each of the JavaScript objects.
var students = [
    { firstName: "Harry", lastName: "Potter", house: "Slytherin" },
    { firstName: "Ron", lastName: "Weasley", house: "Gryffindor" },
    { firstName: "Hermione", lastName: "Granger", house: "Gryffindor" }
];
//COMPLETE YOUR CODE HERE 
// Using the function to display values by the key name
function displayByKey(studentsArray, keyName) {
    // Iterate through each student object in the array
    for (var i = 0; i < studentsArray.legnth; i++){
        // Acces the value
        var value = studentsArray[i][keyName];
    
        // Display our value
        console.log(value);
    }
}

// Display our keys for the students variable
displayByKey(students, "firstName");
displayByKey(students, "lastName");
displayByKey(students, "house");

